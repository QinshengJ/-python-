import numpy as np
import qiskit
from qiskit import QuantumCircuit
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator

from mottonen_calculation import get_flat_theta_y_len, get_flat_theta_y
from mottonen_qiskit import real_state_prep_qiskit


# 在 Qiskit 框架上执行特征提取工作的执行器，负责量子电路的构造和测量结果的统计、转换
# 该类用于开发过程中的一些验证工作，并可能有助于在IBM上运行相关电路（Qiskit 为 IBM 官方使用的框架）
# 若最终不需要使用 Qiskit 框架，可删除，并在 quantum_net.py 中删除对应代码

class QiskitFeatureLayerExecutor:
    def __init__(self, backend=None):
        self.output_dims = 3
        self.params_info = [
            ('c1_weight', (5 * 3,)),
            ('p1_weight', (5 * 3 * 3,)),
            ('c2_weight', (5 * 3,)),
            ('p2_weight', (2 * 3 * 3,)),
        ]
        self.backend = backend if backend is not None else AerSimulator()
        self.shots = 1000

        self.c1_weight = ParameterVector('c1_weight', 5 * 3)
        self.p1_weight = ParameterVector('p1_weight', 5 * 3 * 3)
        self.c2_weight = ParameterVector('c2_weight', 5 * 3)
        self.p2_weight = ParameterVector('p2_weight', 2 * 3 * 3)
        self.state_prep_y = ParameterVector("state_prep_y", get_flat_theta_y_len(10))

        self.circuit = self.__construct_circuit()
        self.circuit = qiskit.transpile(self.circuit, self.backend)

    @staticmethod
    def __conv_gate(c: QuantumCircuit, weight: ParameterVector, wire1, wire2):
        c.rz(weight[0], wire1)
        c.ry(weight[1], wire1)
        c.rz(weight[2], wire1)
        c.rz(weight[3], wire2)
        c.ry(weight[4], wire2)
        c.rz(weight[5], wire2)
        c.cnot(wire2, wire1)
        c.rz(weight[6], wire1)
        c.ry(weight[7], wire2)
        c.cnot(wire1, wire2)
        c.ry(weight[8], wire2)
        c.cnot(wire2, wire1)
        c.rz(weight[9], wire1)
        c.ry(weight[10], wire1)
        c.rz(weight[11], wire1)
        c.rz(weight[12], wire2)
        c.ry(weight[13], wire2)
        c.rz(weight[14], wire2)

    @staticmethod
    def __pool_gate(c: QuantumCircuit, weight: ParameterVector, wire1, wire2):
        c.rz(weight[0], wire2)
        c.ry(weight[1], wire2)
        c.rz(weight[2], wire2)
        c.rz(weight[3], wire1)
        c.ry(weight[4], wire1)
        c.rz(weight[5], wire1)
        c.cnot(wire2, wire1)
        c.measure(wire2, 0)
        c.rz(weight[6], wire1)
        c.ry(weight[7], wire1)
        c.rz(weight[8], wire1)

    def __construct_circuit(self):
        c = QuantumCircuit(10, self.output_dims)

        # encode
        real_state_prep_qiskit(c, self.state_prep_y, 10)

        # conv 1
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c1_weight, wire1=1, wire2=2)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c1_weight, wire1=3, wire2=4)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c1_weight, wire1=5, wire2=6)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c1_weight, wire1=7, wire2=8)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c1_weight, wire1=0, wire2=1)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c1_weight, wire1=2, wire2=3)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c1_weight, wire1=4, wire2=5)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c1_weight, wire1=6, wire2=7)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c1_weight, wire1=8, wire2=9)

        # pool 1
        for i in range(0, 10, 2):
            QiskitFeatureLayerExecutor.__pool_gate(c, self.p1_weight[(int(i / 2) * 9):(int(i / 2) * 9 + 9)], wire1=i,
                                                   wire2=i + 1)

        # conv 2
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c2_weight, wire1=0, wire2=2)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c2_weight, wire1=4, wire2=6)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c2_weight, wire1=2, wire2=4)
        QiskitFeatureLayerExecutor.__conv_gate(c, self.c2_weight, wire1=6, wire2=8)

        # pool 2
        QiskitFeatureLayerExecutor.__pool_gate(c, self.p2_weight[0:9], wire1=0, wire2=2)
        QiskitFeatureLayerExecutor.__pool_gate(c, self.p2_weight[9:18], wire1=8, wire2=6)

        # measure
        c.measure(0, 0)
        c.measure(4, 1)
        c.measure(8, 2)
        return c

    def submit(self, input_feature, c1_weight, p1_weight, c2_weight, p2_weight):
        flat_feature = input_feature.reshape(-1)
        padded_feature = np.pad(flat_feature, (0, 2 ** 10 - flat_feature.shape[0]))
        bound_circuit = self.circuit.bind_parameters({
            self.state_prep_y: get_flat_theta_y(padded_feature, 10),
            self.c1_weight: c1_weight,
            self.p1_weight: p1_weight,
            self.c2_weight: c2_weight,
            self.p2_weight: p2_weight,
        })
        return self.backend.run(bound_circuit, shots=self.shots)

    def query_result(self, query_id):
        raw = query_id.result().get_counts()
        expectation = np.zeros(self.output_dims, dtype=float)
        for bin_string, probability in raw.items():
            expectation += np.array([-1 if c == '1' else 1 for c in reversed(bin_string)],
                                    dtype=float) * probability / self.shots
        return expectation
