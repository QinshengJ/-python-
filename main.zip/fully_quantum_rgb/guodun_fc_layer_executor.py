"""
该文件实现了在国盾量子平台上执行全连接层（Fully-connected layer）的执行器
"""
import time

import numpy as np
import pyezQ

from qcis_builder import *


def normalize_angle(angle):
    """
    正则化角度值，将其调整到 [-pi, +pi] 区间内
    """
    normalized_angle = angle % (2.0 * np.pi)
    if isinstance(angle, np.ndarray):
        normalized_angle[normalized_angle > np.pi] -= 2.0 * np.pi
    elif normalized_angle > np.pi:
        normalized_angle -= 2.0 * np.pi

    # 我们统一使用 7 位小数的数值精度
    # 四舍五入 np.pi 到 7 位小数时将得到 3.1415927，这可能导致不必要的错误
    # 我们使用 3.1415926 （小于 3.1415926535...）作为 PI 值
    fuck_pi = 3.1415926
    normalized_angle = np.clip(normalized_angle, -fuck_pi, +fuck_pi)
    return normalized_angle


class GuoDunFCLayerExecutor:
    """
    在国盾量子平台上执行全连接层（Fully-connected layer）的执行器，负责量子电路的构造和测量结果的统计、转换
    """

    def __init__(self, account: pyezQ.Account, n_qubits, n_layers, measure_type='Z', n_out=None):
        self.n_qubits = n_qubits
        self.n_layers = n_layers
        self.output_dims = n_out if n_out is not None else n_qubits
        self.__measure_type = measure_type.upper()
        if not self.__measure_type in ['X', 'Y', 'Z']:
            raise RuntimeError("unsupported measure type for quantum fc layer")

        self.n_params = n_qubits * n_layers * 3
        self.params_info = [('params', (self.n_params,))]
        self.account = account

    def __construct_circuit(self, input_feature, params):
        """
        根据传递进来的参数动态构造量子电路
        """
        ranges = [(l % (self.n_qubits - 1)) + 1 for l in range(self.n_layers)]
        input_feature = normalize_angle(input_feature)
        params = normalize_angle(params)
        q = ["Q" + str(x) for x in range(self.n_qubits)]
        circuit = QcisBuilder()
        for i in range(self.n_qubits):
            circuit << H(q[i])
        for i in range(self.n_qubits):
            circuit << RZ(q[i], input_feature[i])

        for layer_i in range(self.n_layers):
            for qubit_i in range(self.n_qubits):
                circuit << RZ(q[qubit_i], params[(layer_i * self.n_qubits + qubit_i) * 3 + 0])
                circuit << RY(q[qubit_i], params[(layer_i * self.n_qubits + qubit_i) * 3 + 1])
                circuit << RZ(q[qubit_i], params[(layer_i * self.n_qubits + qubit_i) * 3 + 2])
            for qubit_i in range(self.n_qubits):
                circuit << CNOT(q[qubit_i], q[(qubit_i + ranges[layer_i]) % self.n_qubits])

        if self.__measure_type == 'X':
            for i in range(self.output_dims):
                circuit << H(q[i])
        elif self.__measure_type == 'Y':
            for i in range(self.output_dims):
                circuit << SDagger(q[i])
                circuit << H(q[i])

        for i in range(self.output_dims):
            circuit << M(q[i])

        qcis_circuit = circuit.getvalue()
        qcis_circuit = self.account.qcis_mapping_isq(qcis_circuit)
        # 关闭额外验证以提高运行效率
        # qcis_mapping_isq 不应该输出无效代码
        # if self.account.qcis_check_regular(qcis_circuit) == 0:
        #     raise RuntimeError("Circuit Error")
        return qcis_circuit

    def submit(self, input_feature, params):
        """
        提交量子电路运行任务，返回任务ID，使用 query_result 查询任务结果
        """
        circuit = self.__construct_circuit(input_feature, params)
        query_id = self.account.submit_job(circuit)
        while query_id == 0:
            print("运行失败，30s后重试")
            time.sleep(30)
            query_id = self.account.submit_job(circuit)
        return query_id

    def __expected_value(self, all_probability):
        """
        从测量结果计算出每个比特的期望值
        """

        # 注：all_probability 中的 bin string 是大端序的
        # 需要使用 reversed(bin_string)
        expectation = np.zeros(self.output_dims, dtype=float)
        for bin_string, probability in all_probability.items():
            expectation += np.array([-1 if c == '1' else 1 for c in reversed(bin_string)], dtype=float) * probability
        return expectation

    def query_result(self, query_id):
        """
        查询任务结果，并从测量结果计算出每个比特的期望值。
        """
        result = self.account.query_experiment(query_id, max_wait_time=360000, result_type=0)[0]
        probability = self.account.probability_calibration(result)
        probability = self.account.probability_correction(probability)
        return self.__expected_value(probability)
