"""
该文件的主要作用是为域自适应任务提供一个完整的训练流程。
该文件将创建数据加载器、模型对象和 Adam 优化器，并循环进行前向传播和反向传播、参数的迭代更新，以进行模型训练。
同时我们还将在训练训练过程中进行一些必要的过程记录和实时状态的显示。
"""

import datetime
import os
import random
import sys
from pathlib import Path

import numpy as np
import torch.backends.cudnn as cudnn
import torch.optim as optim
import torch.utils.data

from dataset_transform import dataset_source_train, dataset_target_train, \
    target_dataset_name, label_map, dataset_class, image_size
from model import CNNModel
from test import test

# 进行模型训练的入口
if __name__ == "__main__":
    # 这部分代码用于指定模型的保存路径
    # 我们根据当前的日期和时间创建一个新的文件夹，以防止多次执行代码时，已经训练好的模型被覆盖。
    model_root = 'models/' + datetime.datetime.now().strftime("exp_%Y%m%d_%H%M%S")
    Path(model_root).mkdir(parents=True, exist_ok=True)
    # 这里定义了模型文件的名称，
    # 我们将源域数据集名称、目标域数据集名称以及图像的尺寸信息都包含在了模型文件名中，以便于我们区分不同模型。
    model_filename_prefix = "fully_quantum_{}_{}x{}".format(dataset_class, image_size, image_size)
    model_filename_current = model_filename_prefix + "_current.pt"
    model_filename_best = model_filename_prefix + "_best.pt"

    # 定义训练过程中的参数，包括是否使用CUDA加速、是否启用域适应、学习率、批量大小、迭代次数、保存训练结果的文本文件名以及随机种子。
    cuda = True
    cudnn.benchmark = True
    domain_adaptation_enabled = True
    lr = 1e-3
    batch_size = 64
    n_epoch = 100
    txt_name = 'U2M.txt'
    manual_seed = random.randint(1, 10000)

    # 设置随机种子，并将种子写入文本文件。
    # 在需要时，可以使用相同的随机数种子来完美复现训练过程。
    random.seed(manual_seed)
    torch.manual_seed(manual_seed)

    f = open(txt_name, mode='a')
    f.write('{} seed_num: {}\n'.format(datetime.datetime.now().isoformat(), manual_seed))
    f.close()

    # 创建数据加载器。加载器分为源域加载器（dataloader_source）和目标域加载器（dataloader_target）
    # 加载器加载的数据来源于数据集 dataset_source_train、dataset_target_train，这些数据集对象在 dataset_transform.py 中统一定义。
    dataloader_source = torch.utils.data.DataLoader(
        dataset=dataset_source_train,
        batch_size=batch_size,
        # 自己加的
        drop_last=True,
        shuffle=True,
        num_workers=0)

    dataloader_target = torch.utils.data.DataLoader(
        dataset=dataset_target_train,
        batch_size=batch_size,
        # 自己加的
        drop_last=True,
        shuffle=True,
        num_workers=0)

    # 创建模型对象（my_net），并根据是否启用域适应进行初始化。
    my_net = CNNModel(domain_adaptation_enabled)

    # 定义了优化器，使用Adam优化算法，并将模型参数和学习率传递给优化器。
    optimizer = optim.Adam(my_net.parameters(), lr=lr)

    # 定义分类损失函数和域损失函数，使用负对数似然损失函数（Negative Log Likelihood Loss）。
    # nn.NLLLoss(predict, label)，predict 为网络输出的对数概率向量（LogSoftmax结果），label 为真实标签
    # nn.NLLLoss(predict, label) 把 predict 中 label 对应的对数概率取了负号后取出，默认对取出来后数取平均
    loss_class = torch.nn.NLLLoss()
    loss_domain = torch.nn.NLLLoss()

    # 重新加载模型
    # my_net.load_state_dict(torch.load(os.path.join(
    #      model_root, model_filename_best
    # )))
    # my_net = my_net.eval()

    # 设置一个初值，在关闭域自适应时会被使用
    err_t_domain = err_s_domain = torch.tensor(0, dtype=torch.float)
    if cuda:
        my_net = my_net.cuda()
        loss_class = loss_class.cuda()
        loss_domain = loss_domain.cuda()
        err_t_domain = err_t_domain.cuda()
        err_s_domain = err_s_domain.cuda()

    for p in my_net.parameters():
        p.requires_grad = True

    # best accuracy
    best_accu_t = 0.0

    for epoch in range(n_epoch):
        # 源域和目标域的数据集可能具有不同的大小。
        # 我们需要在加载数据时，以较小的数据集为准。
        len_dataloader = min(len(dataloader_source), len(dataloader_target))
        data_source_iter = iter(dataloader_source)
        data_target_iter = iter(dataloader_target)

        for i in range(len_dataloader):
            # 在每个迭代中，调整梯度反转层的权值因子，用于调整域自适应的程度。
            # p 代表训练进度（百分比），从 0 到 1 递增
            p = float(i + epoch * len_dataloader) / n_epoch / len_dataloader
            # alpha 从 0 慢慢接近 1，递增，使用 Sigmoid 函数的一种变形
            alpha = 2. / (1. + np.exp(-10 * p)) - 1

            # 使用源数据集训练模型
            data_source = next(data_source_iter)
            # s_img 为 batch_size*1*28*28 维张量，s_label 为 batch_size 维张量
            s_img, s_label = data_source
            s_label = label_map(s_label)

            my_net.zero_grad()
            batch_size = len(s_label)
            domain_label = torch.zeros(batch_size).long()

            if cuda:
                s_img = s_img.cuda()
                s_label = s_label.cuda()
                domain_label = domain_label.cuda()

            class_output, domain_output = my_net(input_data=s_img, alpha=alpha)
            # 源域标签损失
            # err_s_label 为 batch_size 个样本（一个batch） 上的标签分类器的损失
            err_s_label = loss_class(class_output, s_label)
            if domain_adaptation_enabled:
                # 源域域损失
                # domain_output 是 batch_size*2 维张量，domain_label 为 batch_size 维张量
                # 源域标签为 0
                err_s_domain = loss_domain(domain_output, domain_label)

                # 使用目标域数据训练标签分类器
                data_target = next(data_target_iter)
                # t_img 为 batch_size*3*28*28 的张量
                t_img, _ = data_target
                batch_size = len(t_img)

                # 目标域标签为 1
                domain_label = torch.ones(batch_size).long()

                if cuda:
                    t_img = t_img.cuda()
                    domain_label = domain_label.cuda()
                _, domain_output = my_net(input_data=t_img, alpha=alpha)
                # 目标域损失
                err_t_domain = loss_domain(domain_output, domain_label)

                # 合成总损失
                err = err_t_domain + err_s_domain + err_s_label
            else:
                # 合成总损失，在关闭域适应的情况下，总损失 = 源域标签损失
                err = err_s_label

            # 梯度反向传播及优化
            err.backward()
            optimizer.step()

            # 在控制台输出当前的训练状态信息
            sys.stdout.write('\r epoch: %d, [iter: %d / all %d], err_s_label: %f, err_s_domain: %f, err_t_domain: %f' \
                             % (epoch + 1, i + 1, len_dataloader, err_s_label.data.cpu().numpy(),
                                err_s_domain.data.cpu().numpy(), err_t_domain.data.cpu().item()))
            sys.stdout.flush()

            # 保存最新的模型数据
            torch.save(my_net.state_dict(), os.path.join(
                model_root, model_filename_current
            ))

        # 在每一 epoch 训练结束后，测试一下模型在目标域上的分类准确率
        # 并选举出最好的模型，保存到命名为 *_best 的文件中
        print('\n')
        accu_t = test(my_net.state_dict(), target_dataset_name)
        print('Accuracy of the {} dataset: {}\n'.format(target_dataset_name, accu_t))
        if accu_t > best_accu_t:
            best_accu_t = accu_t
            torch.save(my_net.state_dict(), os.path.join(
                model_root, model_filename_best
            ))

        # 将每一 epoch 的准确率保存到日志文件中
        f = open(txt_name, mode='a')
        f.write('{} epoch: {}  accuracy of {}: {}\n'.format(datetime.datetime.now().isoformat(), epoch + 1,
                                                            target_dataset_name, accu_t))
        f.close()

    # 训练完成，输出一些总结信息，如最优模型的准确率，最优模型的文件名等
    print('============ Summary ============= \n')
    print('Accuracy of the {} dataset: {}\n'.format(target_dataset_name, best_accu_t))
    print('Corresponding model was save in ' + model_root + '/' + model_filename_best)

    # 将最优模型的准确率信息保存到日志文件中
    f = open(txt_name, mode='a')
    f.write('{} best accuracy of of {}: {}\n'.format(datetime.datetime.now().isoformat(), target_dataset_name, best_accu_t))
    f.close()
