"""
本文件定义了⼀些辅助的可微函数（`torch.autograd.Function`），如梯度反转算⼦（`ReverseLayerF`）
"""

from torch.autograd import Function


# 定义了 DANN 网络需要梯度反转算子，
# 有关梯度反转的作用，参见论文 arXiv:1409.7495 [stat.ML]
class ReverseLayerF(Function):
    """梯度反转算子，其作用参见论文 arXiv:1409.7495 [stat.ML]"""

    # alpha 的取值参见论文 arXiv:1409.7495 [stat.ML] 中的 CNN training procedure 一节
    @staticmethod
    def forward(ctx, x, alpha):
        """
        正向传播。

        参数：
        - ctx (torch.autograd.FunctionContext): 上下文对象，用于保存中间结果，这些中间结果将在反向传播时使用。
        - x: 输入张量
        - alpha: 权值因子，参见论文中的训练过程

        返回：
        - x: x.view_as(x)（用于维持计算图）

        该方法在正向传播时不改变输入张量 x 的值，只是简单地保存 alpha 到上下文中，以用于反向传播时的梯度计算。
        """

        # 正向传播时不改变输入，只是简单地保存 alpha
        ctx.alpha = alpha

        # 注意，返回的张量需要使用 x.view_as(x) 进行操作，以确保计算图正确构建。
        # 如果我们直接原样返回 x，PyTorch 可能会认为我们没有做任何操作，
        # 从而不会调用我们自定义的 backward 函数。
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        """
        反向传播。

        参数：
        - grad_output: 反向传播过程中的梯度输出张量

        返回：
        - output: 与 grad_output 形状相同的张量，表示经过梯度反转后的梯度输出

        该方法在反向传播时将梯度反转并乘以 alpha，作为梯度的输出。
        """
        output = grad_output.neg() * ctx.alpha

        # alpha 不需要梯度，返回 None 作为不需要反向传播的梯度。
        return output, None
