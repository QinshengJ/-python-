import pennylane as qml
import torch
import torch.nn as nn

# 本文件包含在PennyLane上执行特征提取工作的量子电路

n_qubits = 8  # 量子比特数量
dev = qml.device('lightning.qubit', wires=n_qubits)
# 以下代码使用 IBM 量子平台，请确保 pennylane-qiskit 包已安装
# simulator_mps 为 IBM 云端仿真设备，
# 可修改为其它设备如 ibmq_quito、ibmq_manila 等以使用真实量子设备
# dev = qml.device('qiskit.ibmq',
#                  wires=n_qubits,
#                  backend='simulator_mps',
#                  ibmqx_token="<请修改为您自己的 Token>")

# weight 是 5 * 3 大小的矩阵
def ConvGate(weight, wire1, wire2):
    qml.Rot(weight[0][0], weight[0][1], weight[0][2], wires=wire1)
    qml.Rot(weight[1][0], weight[1][1], weight[1][2], wires=wire2)
    qml.CNOT(wires=[wire2, wire1])
    qml.RZ(weight[2][0], wires=wire1)
    qml.RY(weight[2][1], wires=wire2)
    qml.CNOT(wires=[wire1, wire2])
    qml.RY(weight[2][2], wires=wire2)
    qml.CNOT(wires=[wire2, wire1])
    qml.Rot(weight[3][0], weight[3][1], weight[3][2], wires=wire1)
    qml.Rot(weight[4][0], weight[4][1], weight[4][2], wires=wire2)

# weight 是 3 * 3 大小的矩阵
# wire1 保留
def PoolGate(weight, wire1, wire2):
    qml.Rot(weight[0][0], weight[0][1], weight[0][2], wires=wire2)
    qml.Rot(weight[1][0], weight[1][1], weight[1][2], wires=wire1)
    qml.CNOT(wires=[wire2, wire1])
    qml.measure(wire2)
    qml.Rot(weight[2][0], weight[2][1], weight[2][2], wires=wire1)

# weight 是 7 * 5 * 3 大小的矩阵
def conv1(weight):
    ConvGate(weight, wire1=1, wire2=2)
    ConvGate(weight, wire1=3, wire2=4)
    ConvGate(weight, wire1=5, wire2=6)
    ConvGate(weight, wire1=0, wire2=1)
    ConvGate(weight, wire1=2, wire2=3)
    ConvGate(weight, wire1=4, wire2=5)
    ConvGate(weight, wire1=6, wire2=7)

# weight 是 4 * 3 * 3 大小的矩阵
def pool1(weights):
    for i in range(0, n_qubits, 2):
        PoolGate(weights[int(i / 2)], wire1=i, wire2=i + 1)


# weight 是 3 * 5 * 3 大小的矩阵
def conv2(weight):
    ConvGate(weight, wire1=0, wire2=2)
    ConvGate(weight, wire1=4, wire2=6)
    ConvGate(weight, wire1=2, wire2=4)

# weight 是 2 * 3 * 3 大小的矩阵
def pool2(weights):
    PoolGate(weights[0], wire1=0, wire2=2)
    PoolGate(weights[1], wire1=4, wire2=6)

@qml.qnode(dev, interface="torch")
def feature_net(features, c1_weight, p1_weight, c2_weight, p2_weight):
    c1_weight = c1_weight.reshape(5, 3)
    p1_weight = p1_weight.reshape(4, 3, 3)
    c2_weight = c2_weight.reshape(5, 3)
    p2_weight = p2_weight.reshape(2, 3, 3)

    flatten_features = features.reshape(features.shape[0], -1)
    qml.AmplitudeEmbedding(features=flatten_features, wires=range(n_qubits), normalize=True, pad_with=0)

    conv1(c1_weight)
    pool1(p1_weight)
    conv2(c2_weight)
    pool2(p2_weight)

    return tuple(qml.expval(qml.PauliZ(wires=position)) for position in range(0, n_qubits, 4))


# 8*8 -> 2
class PennylaneFeatureLayer(nn.Module):
    def __init__(self):
        super().__init__()
        self.c1_weight = nn.Parameter(torch.rand(5 * 3))
        self.p1_weight = nn.Parameter(torch.rand(4 * 3 * 3))
        self.c2_weight = nn.Parameter(torch.rand(5 * 3))
        self.p2_weight = nn.Parameter(torch.rand(2 * 3 * 3))

    def forward(self, inputs):
        outputs = feature_net(inputs, self.c1_weight, self.p1_weight, self.c2_weight, self.p2_weight)
        return torch.t(torch.stack(outputs).float())
