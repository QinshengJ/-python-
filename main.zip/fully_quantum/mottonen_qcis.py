from mottonen_calculation import get_flat_theta_y_len, get_uniform_rotation_controls
from qcis_builder import *


# 使用 Mottonen 算法进行全振幅编码，构造 QCIS 指令
# 高度参考：
# https://docs.pennylane.ai/en/stable/code/api/pennylane.MottonenStatePreparation.html
# https://arxiv.org/abs/quant-ph/0407010

def __apply_uniform_ry_dagger_theta(q_circuit: QcisBuilder, theta, control_wires, target_wire: int) -> None:
    k = len(control_wires)
    if k == 0:
        q_circuit << RY(target_wire, theta[0])
        return

    control_indices = get_uniform_rotation_controls(k)

    for i, control_index in enumerate(control_indices):
        q_circuit << RY(target_wire, theta[i])
        q_circuit << CNOT(control_wires[control_index], target_wire)


def real_state_prep_qcis(flat_theta_y, num_qubits: int, wires) -> str:
    assert len(flat_theta_y) == get_flat_theta_y_len(num_qubits)
    c = QcisBuilder()
    y_start = 0
    y_end = 1
    for k in range(num_qubits, 0, -1):
        theta_y_k = flat_theta_y[y_start:y_end]
        y_start = y_start * 2 + 1
        y_end = y_start * 2 + 1
        __apply_uniform_ry_dagger_theta(c, theta_y_k, [wires[i] for i in range(num_qubits - k - 1, -1, -1)],
                                        wires[num_qubits - k])
    return c.getvalue()
