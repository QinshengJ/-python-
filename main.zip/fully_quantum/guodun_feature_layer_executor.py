import time

import numpy as np
import pyezQ

from mottonen_calculation import get_flat_theta_y
from mottonen_qcis import real_state_prep_qcis
from qcis_builder import *


# 在国盾量子平台上执行特征提取工作的执行器，负责量子电路的构造和测量结果的统计、转换
class GuoDunFeatureLayerExecutor:
    def __init__(self, account: pyezQ.Account):
        self.output_dims = 2
        self.params_info = [
            ('c1_weight', (5 * 3,)),
            ('p1_weight', (4 * 3 * 3,)),
            ('c2_weight', (5 * 3,)),
            ('p2_weight', (2 * 3 * 3,)),
        ]
        self.account = account

    @staticmethod
    def __conv_gate(weight, wire1, wire2):
        c = QcisBuilder()
        c << RZ(wire1, weight[0])
        c << RY(wire1, weight[1])
        c << RZ(wire1, weight[2])
        c << RZ(wire2, weight[3])
        c << RY(wire2, weight[4])
        c << RZ(wire2, weight[5])
        c << CNOT(wire2, wire1)
        c << RZ(wire1, weight[6])
        c << RY(wire2, weight[7])
        c << CNOT(wire1, wire2)
        c << RY(wire2, weight[8])
        c << CNOT(wire2, wire1)
        c << RZ(wire1, weight[9])
        c << RY(wire1, weight[10])
        c << RZ(wire1, weight[11])
        c << RZ(wire2, weight[12])
        c << RY(wire2, weight[13])
        c << RZ(wire2, weight[14])
        return c.getvalue()

    @staticmethod
    def __pool_gate(weight, wire1, wire2):
        c = QcisBuilder()
        c << RZ(wire2, weight[0])
        c << RY(wire2, weight[1])
        c << RZ(wire2, weight[2])
        c << RZ(wire1, weight[3])
        c << RY(wire1, weight[4])
        c << RZ(wire1, weight[5])
        c << CNOT(wire2, wire1)
        c << M(wire2) # use measure to reduce the dims of the vector space
        c << RZ(wire1, weight[6])
        c << RY(wire1, weight[7])
        c << RZ(wire1, weight[8])
        return c.getvalue()

    def __construct_circuit(self, input_feature, c1_weight, p1_weight, c2_weight, p2_weight):
        q = ["Q" + str(x) for x in range(8)]
        circuit = QcisBuilder()
        # encode
        circuit << real_state_prep_qcis(get_flat_theta_y(input_feature.reshape(-1), 8), 8, q)

        # conv 1
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c1_weight, wire1=q[1], wire2=q[2])
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c1_weight, wire1=q[3], wire2=q[4])
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c1_weight, wire1=q[5], wire2=q[6])
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c1_weight, wire1=q[0], wire2=q[1])
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c1_weight, wire1=q[2], wire2=q[3])
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c1_weight, wire1=q[4], wire2=q[5])
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c1_weight, wire1=q[6], wire2=q[7])

        # pool 1
        for i in range(0, 8, 2):
            circuit << GuoDunFeatureLayerExecutor.__pool_gate(
                p1_weight[(int(i / 2) * 9):(int(i / 2) * 9 + 9)], wire1=q[i],
                wire2=q[i + 1])

        # conv 2
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c2_weight, wire1=q[0], wire2=q[2])
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c2_weight, wire1=q[4], wire2=q[6])
        circuit << GuoDunFeatureLayerExecutor.__conv_gate(c2_weight, wire1=q[2], wire2=q[4])

        # pool 2
        circuit << GuoDunFeatureLayerExecutor.__pool_gate(p2_weight[0:9], wire1=q[0], wire2=q[2])
        circuit << GuoDunFeatureLayerExecutor.__pool_gate(p2_weight[9:18], wire1=q[4], wire2=q[6])

        # measure
        circuit << M(q[0])
        circuit << M(q[4])

        qcis_circuit = circuit.getvalue()
        qcis_circuit = self.account.qcis_mapping_isq(qcis_circuit)
        if self.account.qcis_check_regular(qcis_circuit) == 0:
            raise RuntimeError("Circuit Error")
        qcis_circuit = self.account.simplify(qcis_circuit)

        return qcis_circuit

    def submit(self, input_feature, c1_weight, p1_weight, c2_weight, p2_weight):
        circuit = self.__construct_circuit(input_feature, c1_weight, p1_weight, c2_weight, p2_weight)
        query_id = self.account.submit_job(circuit)
        while query_id == 0:
            print("运行失败，30s后重试")
            time.sleep(30)
            query_id = self.account.submit_job(circuit)
        return query_id

    def __expected_value(self, all_probability):
        # 注：all_probability 中的 bin string 是大端序的
        # 需要使用 reversed(bin_string)
        expectation = np.zeros(self.output_dims, dtype=float)
        for bin_string, probability in all_probability.items():
            expectation += np.array([-1 if c == '1' else 1 for c in reversed(bin_string[:self.output_dims])], dtype=float) * probability
        return expectation

    def query_result(self, query_id):
        result = self.account.query_experiment(query_id, max_wait_time=360000, result_type=0)[0]
        probability = self.account.probability_calibration(result)
        probability = self.account.probability_correction(probability)
        return self.__expected_value(probability)
