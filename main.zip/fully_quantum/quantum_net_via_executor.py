"""
本文将提供 QuantumNetLayerViaExecutor，将量子网络执行器包装为 PyTorch 中的一个模块，
并使用 parameter-shift rule 以支持梯度计算。
"""

import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Function


class QuantumNetFunctionViaExecutor(Function):
    """
    将量子网络执行器包装为 PyTorch 中的一个可求偏导的函数操作
    注：本实现假设所有参数都是用于 Rx、Ry、Rz 门的，使用 parameter-shift rule 进行梯度计算
    """

    @staticmethod
    def __parameter_shift_term(executor, p_i, i, input_features, *params_list):
        """
        计算某个参数的偏导数值。

        参数:
            - executor (obj): 量子电路执行器，用于执行量子电路操作。
            - p_i (int): 参数索引1
            - i (int): 参数索引2
            - input_features (torch.Tensor): 输入特征张量。
            - *params_list (torch.Tensor): 参数列表，这些参数应均是用于 Rx、Ry、Rz 门的。

        返回:
            - result (numpy.ndarray): 使用 parameter-shift rule 进行偏导数计算的结果。

        """
        shifted = [params.copy() for params in params_list]

        shifted[p_i][i] += np.pi / 2
        if shifted[p_i][i] > np.pi:
            shifted[p_i][i] -= 2 * np.pi
        forward_ids = tuple([executor.submit(x.numpy(), *shifted) for x in torch.unbind(input_features)])

        shifted[p_i][i] -= np.pi
        if shifted[p_i][i] < -np.pi:
            shifted[p_i][i] += 2 * np.pi
        backward_ids = tuple([executor.submit(x.numpy(), *shifted) for x in torch.unbind(input_features)])

        result = np.zeros(executor.output_dims, dtype=float)
        for forward_id, backward_id in zip(forward_ids, backward_ids):
            forward = executor.query_result(forward_id)
            backward = executor.query_result(backward_id)
            result += 0.5 * (forward - backward)

        return result

    @staticmethod
    def forward(ctx, input_features, executor, *params_list):
        """
        前向传播函数操作。

        参数:
            - ctx (torch.autograd.FunctionContext): 上下文对象，用于保存中间结果，这些中间结果将在反向传播时使用。
            - input_features (torch.Tensor): 输入特征张量。
            - executor (obj): 量子电路执行器，用于执行量子电路操作。
            - *params_list (torch.Tensor): 参数列表，这些参数应均是用于 Rx、Ry、Rz 门的。

        返回:
            - result (torch.Tensor): 前向传播的结果张量。

        """
        params_list_cpu = [params.detach().cpu().numpy() for params in params_list]
        input_features_cpu = input_features.detach().cpu()
        result_ids = tuple([executor.submit(x.numpy(), *params_list_cpu)
                            for x in torch.unbind(input_features_cpu)])
        result = torch.stack([torch.tensor(executor.query_result(x), dtype=torch.float) for x in result_ids])
        ctx.params_list_cpu = params_list_cpu
        ctx.input_features_cpu = input_features_cpu
        ctx.fc_executor = executor
        return result.to(input_features.device)

    @staticmethod
    def backward(ctx, grad_output):
        """
        反向传播函数操作。

        参数:
            - ctx (torch.autograd.FunctionContext): 上下文对象，包含前向传播的中间结果。
            - grad_output (torch.Tensor): 反向传播的梯度张量。

        返回:
            - result (tuple): 参数的梯度张量元组。

        """
        grad_output_cpu = grad_output.detach().cpu().numpy()
        result = [] + [None, None]
        for p_i, params in enumerate(ctx.params_list_cpu):
            # 逐参数求解梯度
            output = [np.sum(QuantumNetFunctionViaExecutor.__parameter_shift_term(ctx.fc_executor,
                                                                                  p_i,
                                                                                  i,
                                                                                  ctx.input_features_cpu,
                                                                                  *ctx.params_list_cpu)
                             * grad_output_cpu)
                      for i in range(len(params))]
            result.append(torch.tensor(output).to(grad_output.device))
        return tuple(result)


# 将量子网络执行器包装为 PyTorch 中的一个模块
class QuantumNetLayerViaExecutor(nn.Module):
    """
    量子网络层，将量子网络执行器包装为 PyTorch 中的一个模块。

    参数:
        - executor (obj): 量子电路执行器，用于执行量子电路操作。
        - init_delta (float): 初始化参数的标准差。

    注意：
        - executor 应该具有：
        - - 属性 output_dims (int) 表示量子电路输出的向量长度；
        - - 属性 params_info 描述变分参数的信息；
        - - 方法 submit(input_feature, params) 用于提交量子电路运行任务；
        - - 方法 query_result(query_id) 用于查询量子电路运行结果。
    """

    def __init__(self, executor, init_delta=0.01):
        super().__init__()
        self.executor = executor

        # 根据 init_delta 和 executor（量子电路执行器）提供的参数信息，初始化参数
        for param_name, param_shape in executor.params_info:
            setattr(self, param_name, nn.Parameter(init_delta * torch.randn(*param_shape)))

    def forward(self, inputs):
        """
        前向传播函数。

        参数:
            - inputs (torch.Tensor): 输入张量，包含输入特征的值。

        返回:
            - result (torch.Tensor): 前向传播的结果张量。

        """
        return QuantumNetFunctionViaExecutor.apply(inputs, self.executor,
                                                   *(getattr(self, param_name) for param_name, _ in
                                                     self.executor.params_info))
