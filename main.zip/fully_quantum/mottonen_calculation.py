import numpy as np


# 使用 Mottonen 算法进行全振幅编码时，一些主要的参数的计算
# 高度参考：
# https://docs.pennylane.ai/en/stable/code/api/pennylane.MottonenStatePreparation.html
# https://arxiv.org/abs/quant-ph/0407010

def __alpha_y(state: np.array, n: int, k: int):
    magnitude = np.abs(state)
    indices_numerator = [
        [(2 * (j + 1) - 1) * 2 ** (k - 1) + l for l in range(2 ** (k - 1))]
        for j in range(2 ** (n - k))
    ]
    numerator = np.take(magnitude, indices=indices_numerator, axis=-1)
    numerator = np.sum(np.abs(numerator) ** 2, axis=-1)

    indices_denominator = [[j * 2 ** k + l for l in range(2 ** k)] for j in range(2 ** (n - k))]
    denominator = np.take(magnitude, indices=indices_denominator, axis=-1)
    denominator = np.sum(np.abs(denominator) ** 2, axis=-1)

    with np.errstate(divide="ignore", invalid="ignore"):
        division = numerator / denominator
    division = np.where(denominator != 0.0, division, 0.0)
    return 2 * np.arcsin(np.sqrt(division))


def __get_m_matrix_entry(row: int, col: int, k: int) -> int:
    sum_of_ones = (row & ((col >> 1) ^ col)).bit_count()
    return (2 ** (-k)) * (-1) ** sum_of_ones


def __compute_theta(angle: np.array, k: int):
    size = len(angle)
    m_trans = np.zeros(shape=(size, size))

    for i in range(size):
        for j in range(size):
            m_trans[i][j] = __get_m_matrix_entry(j, i, k)

    return np.transpose(np.dot(m_trans, np.transpose(angle)))


def get_flat_theta_y(input_vector, num_qubits):
    assert num_qubits == int(np.log2(len(input_vector)))
    state = input_vector / np.linalg.norm(input_vector)
    return np.concatenate(
        [__compute_theta(__alpha_y(state, num_qubits, k), num_qubits - k) for k in range(num_qubits, 0, -1)])


def get_flat_theta_y_len(num_qubits):
    return (1 << num_qubits) - 1


def get_uniform_rotation_controls(k):
    gray_code = np.arange(0, 1 << k, dtype=int)
    gray_code = gray_code ^ (gray_code >> 1)
    control_indices = np.log2(gray_code ^ np.roll(gray_code, -1)).astype(int)
    return control_indices
