"""
本文件提供一个统一的量子网络层的构造方法，可以通过修改该文件来轻松切换量子操作的后端.
当前支持三种后端：
- Pennylane
- GuoDun（国盾平台）
- Qiskit

根据所需的后端，应取消注释和修改与特定后端选择相关的代码段。
要选择所需的后端，请将 `current_quantum_backend` 变量设置为相应的 `QuantumBackend` 枚举值。

如果选择 Pennylane 后端，QuantumFCLayer 函数将返回使用 Pennylane 框架实现的层。
如果选择 GuoDun（国盾平台） 后端，QuantumFCLayer 函数将返回使用国盾平台实现的层，请注意您需要修改 login_key 填写您的 Token。
如果选择 Qiskit 后端，QuantumFCLayer 函数将返回使用 Qiskit 框架实现的层，请注意您需要修改 ibm_token 填写您的 Token。

不同实现所使用的参数（nn.Parameter）名称完全相同，故而在一个后端训练得到的模型参数可以直接用于另一个后端。
"""

from enum import Enum


class QuantumBackend(Enum):
    """量子操作的后端类型"""
    Pennylane = 1
    GuoDun = 2
    Qiskit = 3


# 代理配置，IBM API 似乎会拒绝 CN 的 IP 直接访问
# import os
# os.environ['HTTP_PROXY'] = os.environ['http_proxy'] = 'http://172.22.112.1:7890/'
# os.environ['HTTPS_PROXY'] = os.environ['https_proxy'] = 'http://172.22.112.1:7890/'
# os.environ['NO_PROXY'] = os.environ['no_proxy'] = '127.0.0.1,localhost,.local'


current_quantum_backend = QuantumBackend.Pennylane

# noinspection PyUnreachableCode
if current_quantum_backend == QuantumBackend.Pennylane:
    # 使用 Pennylane 框架时，具体的 device 请到对应的文件中修改
    # 如 pennylane_fc_layer.py 文件中
    # 可通过 Pennylane 直接调用 IBM 真实物理量子计算平台或云端仿真器
    from pennylane_fc_layer import PennylaneFCLayer


    # noinspection PyPep8Naming
    def QuantumFCLayer():
        return PennylaneFCLayer()
elif current_quantum_backend == QuantumBackend.GuoDun:
    from guodun_fc_layer_executor import GuoDunFCLayerExecutor
    from quantum_net_via_executor import QuantumNetLayerViaExecutor
    from pyezQ import Account

    login_key = 'e3a0f1ce6c27c1c5f85bbf3935f0dc0f'
    # machine_name = '应答机A' # 应答机返回随机结果，仅用于判断提交流程是否正确
    machine_name = 'ClosedBetaQC'  # 66比特真实超导量子计算平台
    account = Account(login_key=login_key, machine_name=machine_name)
    fc_executor = GuoDunFCLayerExecutor(account, 2, 2)


    # noinspection PyPep8Naming
    def QuantumFCLayer():
        return QuantumNetLayerViaExecutor(fc_executor)
elif current_quantum_backend == QuantumBackend.Qiskit:
    from qiskit_fc_layer_executor import QiskitFCLayerExecutor
    from quantum_net_via_executor import QuantumNetLayerViaExecutor
    # noinspection PyUnresolvedReferences
    from qiskit_ibm_provider import IBMProvider, least_busy
    # noinspection PyUnresolvedReferences
    from qiskit_aer import AerSimulator

    # ibm_token = "<请修改为您自己的 Token>"

    # 以下代码自动选取最空闲的真实量子计算机
    # 修改量子电路时，请注意 min_num_qubits 的值
    # provider = IBMProvider(
    #     token=ibm_token,
    # )
    # backend = least_busy(
    #     provider.backends(
    #         simulator=False, operational=True, min_num_qubits=2
    #     )
    # )

    # 以下代码设置后端为云仿真
    # provider = IBMProvider(
    #     token=ibm_token,
    # )
    # backend = provider.get_backend("simulator_mps")

    # 以下代码设置后端为本地仿真
    backend = AerSimulator()
    fc_executor = QiskitFCLayerExecutor(2, 2, backend)


    # noinspection PyPep8Naming
    def QuantumFCLayer():
        return QuantumNetLayerViaExecutor(fc_executor)
else:
    raise RuntimeError("Unknown quantum backend is chosen: {}".format(current_quantum_backend))
