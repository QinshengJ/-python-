"""
本文件包含在PennyLane上执行全连接层（Fully-connected layer）的量子电路
"""

import pennylane as qml
import torch
import torch.nn as nn
from pennylane.templates import StronglyEntanglingLayers
n_qubits = 2  # 量子比特数量
n_layers = 2  # 变分电路深度

dev = qml.device('lightning.qubit', wires=n_qubits)


# 以下代码使用 IBM 量子平台，请确保 pennylane-qiskit 包已安装
# simulator_mps 为 IBM 云端仿真设备，
# 可修改为其它设备如 ibmq_quito、ibmq_manila 等以使用真实量子设备
# dev = qml.device('qiskit.ibmq',
#                  wires=n_qubits,
#                  backend='simulator_mps',
#                  ibmqx_token="<请修改为您自己的 Token>")

@qml.qnode(dev, interface="torch")
def pennylane_fc_layer(q_weights_flat, q_input_features):
    for idx in range(n_qubits):
        qml.Hadamard(wires=idx)

    qml.AngleEmbedding(features=q_input_features, wires=range(n_qubits), rotation='Z')

    q_weights = q_weights_flat.reshape(n_layers, n_qubits, 3)
    StronglyEntanglingLayers(q_weights, wires=range(n_qubits))

    return tuple(qml.expval(qml.PauliZ(wires=position)) for position in range(n_qubits))


class PennylaneFCLayer(nn.Module):
    def __init__(self, init_delta=0.01):
        super().__init__()
        # 给定一个参数初值
        self.params = nn.Parameter(init_delta * torch.randn(n_qubits * n_layers * 3, dtype=torch.float))

    def forward(self, inputs):
        outputs = pennylane_fc_layer(self.params, inputs)
        # PennyLane原始输出格式为
        # [
        #     (PauliZ(wires=0) for sample 1, PauliZ(wires=0) for sample 2, ...),
        #     (PauliZ(wires=1) for sample 1, PauliZ(wires=1) for sample 2, ...),
        #     (PauliZ(wires=2) for sample 1, PauliZ(wires=2) for sample 2, ...),
        #     ...
        # ]
        # 我们需要将输出转换为 PyTorch 需要的格式
        return torch.t(torch.stack(outputs).float())
