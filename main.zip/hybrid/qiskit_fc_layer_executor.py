"""
该文件实现了在 Qiskit 框架上执行全连接层（Fully-connected layer）的执行器
"""

import numpy as np
import qiskit
from qiskit import QuantumCircuit
from qiskit.circuit import ParameterVector
from qiskit_aer import AerSimulator


class QiskitFCLayerExecutor:
    """
    在 Qiskit 框架上执行全连接层（Fully-connected layer）的执行器，负责量子电路的构造和测量结果的统计、转换
    """

    def __init__(self, n_qubits, n_layers, backend=None):
        self.n_qubits = n_qubits
        self.n_layers = n_layers
        self.n_params = n_qubits * n_layers * 3
        self.output_dims = n_qubits
        self.params_info = [('params', (self.n_params,))]
        self.ranges = [(l % (n_qubits - 1)) + 1 for l in range(n_layers)]
        self.backend = backend if backend is not None else AerSimulator()
        self.shots = 1000

        self.params = ParameterVector('p', self.n_params)
        self.input_feature = ParameterVector('in', self.n_qubits)
        self.circuit = self.__construct_circuit()
        self.circuit = qiskit.transpile(self.circuit, self.backend)

    def __construct_circuit(self):
        c = QuantumCircuit(self.n_qubits, self.n_qubits)
        for i in range(self.n_qubits):
            c.h(i)
        for i in range(self.n_qubits):
            c.rz(self.input_feature[i], i)
        for layer_i in range(self.n_layers):
            for qubit_i in range(self.n_qubits):
                c.rz(self.params[(layer_i * self.n_qubits + qubit_i) * 3 + 0], qubit_i)
                c.ry(self.params[(layer_i * self.n_qubits + qubit_i) * 3 + 1], qubit_i)
                c.rz(self.params[(layer_i * self.n_qubits + qubit_i) * 3 + 2], qubit_i)
            for qubit_i in range(self.n_qubits):
                c.cnot(qubit_i, (qubit_i + self.ranges[layer_i]) % self.n_qubits)
        for i in range(self.n_qubits):
            c.measure(i, i)
        return c

    def submit(self, input_feature, params):
        """
        提交量子电路运行任务，返回任务ID，使用 query_result 查询任务结果
        """

        # 绑定参数并运行量子电路
        bound_circuit = self.circuit.bind_parameters({
            self.input_feature: input_feature,
            self.params: params
        })
        return self.backend.run(bound_circuit, shots=self.shots)

    def query_result(self, query_id):
        """
        查询任务结果，并从测量结果计算出每个比特的期望值。
        """
        raw = query_id.result().get_counts()

        # 从测量结果计算出每个比特的期望值
        # 注：all_probability 中的 bin string 是大端序的
        # 需要使用 reversed(bin_string)
        expectation = np.zeros(self.n_qubits, dtype=float)
        for bin_string, probability in raw.items():
            expectation += np.array([-1 if c == '1' else 1 for c in reversed(bin_string)],
                                    dtype=float) * probability / self.shots
        return expectation
