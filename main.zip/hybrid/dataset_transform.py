"""
本文件统一定义了源域、目标域的训练集、测试集、预处理规则（Transform）等，
供 main.py、test.py、demo.py 等文件
"""

import os

from torchvision import transforms, datasets

from data_loader import GetLoader

# 预处理后的图像大小
image_size = 28

# 源域图像的预处理规则
img_transform_source = transforms.Compose([
    transforms.Resize(image_size),
    transforms.ToTensor(),
    transforms.Normalize(mean=(0.0811, 0.0811, 0.0811), std=(0.2354, 0.2354, 0.2354)),
    transforms.Grayscale(num_output_channels=1)
])

# 目标域图像的预处理规则
img_transform_target = transforms.Compose([
    transforms.Resize(image_size),
    transforms.ToTensor(),
    transforms.Normalize(mean=(0.1307,), std=(0.3081,))
])

# 源域数据集名称
source_dataset_name = 'USPS'
# 目标域数据集名称
target_dataset_name = 'MNIST'
# 源域数据集根目录
source_image_root = os.path.join('dataset', source_dataset_name)
# 目标域数据集根目录
target_image_root = os.path.join('dataset', target_dataset_name)

# 源域训练集
dataset_source_train = GetLoader(
    data_root=os.path.join(source_image_root, 'USPS_train'),
    data_list=os.path.join(source_image_root, 'USPS_train_labels.txt'),
    transform=img_transform_source
)

# 源域测试集
dataset_source_test = GetLoader(
    data_root=os.path.join(source_image_root, 'USPS_test'),
    data_list=os.path.join(source_image_root, 'USPS_test_labels.txt'),
    transform=img_transform_source
)

# 目标域训练集
dataset_target_train = datasets.MNIST(
    root='dataset',
    train=True,
    transform=img_transform_target,
    download=True
)

# 目标域测试集
dataset_target_test = datasets.MNIST(
    root='dataset',
    train=False,
    transform=img_transform_target,
)

# 目标域测试集（不应用预处理规则）
dataset_target_test_without_transform = datasets.MNIST(
    root='dataset',
    train=False,
)