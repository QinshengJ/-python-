"""
本文件提供了一些用于构造 QCIS 指令的辅助工具
"""

# pylint: disable=invalid-name
# pylint: disable=expression-not-assigned
# pyright: reportUnusedExpression=none
from io import StringIO


def H(q):
    """Hadamard门"""
    return "H " + q


def X(q):
    """Pauli-X 门，或称为 NOT 门"""
    return "X " + q


def Z(q):
    """Pauli-Z 门"""
    return "Z " + q

def Y2M(q):
    """RY(-pi/2) 门"""
    return "Y2M " + q

def Y2P(q):
    """RY(pi/2) 门"""
    return "Y2P " + q

def CZ(q1, q2):
    """受控 Pauli-Z 门"""
    return "CZ " + q1 + " " + q2

def RX(q, theta):
    """绕 X 轴旋转 theta 角度的旋转门"""
    return "RX " + q + " " + str(theta)

def RY(q, theta):
    """绕 Y 轴旋转 theta 角度的旋转门"""
    return "RY " + q + " " + str(theta)

def RZ(q, theta):
    """绕 Z 轴旋转 theta 角度的旋转门"""
    return "RZ " + q + " " + str(theta)

def CNOT(q1, q2):
    """受控 NOT 门"""
    builder = QcisBuilder()
    builder << Y2M(q2)
    builder << CZ(q1, q2)
    builder << Y2P(q2)
    return builder.getvalue()

def T(q):
    """T 门（π/4 相移门）"""
    return "T " + q

def M(q):
    """测量指令"""
    return "M " + q

def TDagger(q):
    """T 门的共轭转置"""
    return "TD " + q

def Toffoli(q1, q2, q3):
    """Toffoli 门，或称 CCNOT/CCX 门"""
    builder = QcisBuilder()
    builder << H(q3)\
            << CNOT(q2, q3)\
            << TDagger(q3)\
            << CNOT(q1, q3)\
            << T(q3)\
            << CNOT(q2, q3)\
            << TDagger(q3)\
            << CNOT(q1, q3)\
            << T(q2)\
            << T(q3)\
            << CNOT(q1, q2)\
            << H(q3)\
            << T(q1)\
            << TDagger(q2)\
            << CNOT(q1, q2)
    return builder.getvalue()


class QcisBuilder:
    """
    用于构造 QCIS 指令的辅助工具
    """

    def __init__(self):
        self.result = StringIO()

    def __lshift__(self, other):
        self.result.write(other)
        self.result.write('\n')
        return self

    def getvalue(self):
        """
        获取构造的指令
        """
        return self.result.getvalue()[0:-1]
