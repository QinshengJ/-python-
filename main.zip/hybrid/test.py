"""
该文件的主要作用是为域自适应任务提供一个完整的测试流程。
本文件将被 main.py 文件调用，以便在训练过程中选举出效果最好的模型。
本文件也可单独运行，用于评估已训练好的模型的效果。

本文件用于得到量化的准确率信息，如果需要预测结果以可视化方式展示，请使用 demo.py 文件。
"""
import glob
import os
import random
import sys
import time

import numpy as np
import torch.backends.cudnn as cudnn
import torch.utils.data
from torch.utils.data import RandomSampler, SubsetRandomSampler

from dataset_transform import target_dataset_name, dataset_target_test, \
    dataset_source_test, source_dataset_name
from model import CNNModel

model_root = 'models'


def test(state_dict, dataset_name, size_limit=-1):
    """
    测试函数，根据指定的参数创建模型，并根据指定的大小选取来自目标域或源域的样本，
    对所有选取的样本进行预测，返回预测准确率，用于评估模型性能。

    参数:
        - state_dict (dict): 包含模型权重信息的字典。
        - dataset_name (str): 数据集名称，可以是源域或目标域的名称。
        - size_limit (int, optional): 选取样本的大小限制，默认为-1表示不限制。

    返回:
        float: 预测准确率。

    注意:
        - dataset_name 参数只能是 source_dataset_name 或 target_dataset_name。
        - 调用该函数需要提供模型权重信息 state_dict。

    """

    assert dataset_name in [source_dataset_name, target_dataset_name]
    cuda = True
    cudnn.benchmark = True
    batch_size = 64
    alpha = 0

    # 加载数据

    if dataset_name == target_dataset_name:
        dataset = dataset_target_test
    else:
        dataset = dataset_source_test

    if size_limit < 0 or len(dataset) <= size_limit:
        sampler = RandomSampler(dataset)
    else:
        indices = torch.randperm(len(dataset))[:size_limit]
        sampler = SubsetRandomSampler(indices)  # type: ignore

    dataloader = torch.utils.data.DataLoader(
        dataset=dataset,
        batch_size=batch_size,
        sampler=sampler,
        num_workers=0
    )

    # 测试

    my_net = CNNModel()
    my_net.load_state_dict(state_dict)
    # 使用 model.eval() 来切换到求解模式（默认为训练模式），这将导致：
    # - 改变 BN 层行为，直接利用之前训练阶段得到的均值和方差
    # - 改变 Dropout 层行为，不进行随机舍弃神经元的操作（该操作仅在训练中有用）
    # - 关闭域分类器，减小无用计算量（域分类器仅在训练中有用）
    my_net = my_net.eval()

    if cuda:
        my_net = my_net.cuda()

    n_total = 0
    n_correct = torch.tensor(0)

    for data_target in dataloader:
        t_img, t_label = data_target

        batch_size = len(t_label)

        if cuda:
            t_img = t_img.cuda()
            t_label = t_label.cuda()

        class_output, _ = my_net(input_data=t_img, alpha=alpha)
        # 下面是把最大对数概率值的所在位置选出来
        # pred 是 batch_size*1 维的张量
        pred = class_output.data.max(1, keepdim=True)[1]
        n_correct += pred.eq(t_label.data.view_as(pred)).cpu().sum()
        n_total += batch_size

    accu = n_correct.data.numpy() * 1.0 / n_total

    return accu


# 调用 test 进行项目展示的入口
# 注：test 方法不仅在此处被调用，也同样在训练时被 main.py 调用
if __name__ == "__main__":
    # 指定随机数种子并输出，
    # 在需要时，可以使用相同的随机数种子来完美复现。
    manual_seed = random.randint(1, 10000)
    random.seed(manual_seed)
    torch.manual_seed(manual_seed)
    np.random.seed(manual_seed)
    print("Using random seed: {}".format(manual_seed))

    # 搜索获取所有参数文件
    pt_files = glob.glob('**/*.pt', root_dir=model_root, recursive=True)

    if len(pt_files) == 0:
        print("No .pt files found in the model_root directory.")
        sys.exit(-10001)

    print("Found the following files of model parameters:")
    for i, file in enumerate(pt_files):
        print("{}. {}".format(i + 1, file))

    # 询问用户选择
    choice = int(input("Choose a file (enter the corresponding number): "))

    if 1 <= choice <= len(pt_files):
        # 选中的文件路径
        print("File chosen: " + pt_files[choice - 1])
        selected_file = os.path.join(model_root, pt_files[choice - 1])
    else:
        print("Invalid choice.")
        sys.exit(-10001)

    time_start = time.monotonic()
    accu_t = test(torch.load(selected_file), target_dataset_name)
    time_elapsed = time.monotonic() - time_start
    print('Accuracy of the %s dataset: %f\n' % (target_dataset_name, accu_t))
    print('Time elapsed: %fs\n' % (time_elapsed,))
