"""
定义了数据加载器（类），用于加载数据集。
dataset_transform.py 中会首先拼接路径，然后在加载数据集时调用本文件中的 GetLoader。
"""

import os

import torch.utils.data as data
from PIL import Image


class GetLoader(data.Dataset):
    """
    图片数据集加载器，适用于以 `{filename} {label}` 格式的 TXT 标注的数据集合
    """

    def __init__(self, data_root, data_list, transform=None):
        """
        数据加载器的初始化方法。

        参数:
            data_root (str): 数据集根目录路径。
            data_list (str): 包含图片文件名和标签的 TXT 文件路径。
            transform (callable, optional): 对图片进行的预处理操作，默认为None。

        属性:
            root (str): 数据集根目录路径。
            transform (callable): 图片预处理操作。
            n_data (int): 数据集中的样本数量。
            img_paths (list): 图片文件路径列表。
            img_labels (list): 图片标签列表。

        """
        self.root = data_root
        self.transform = transform

        with open(data_list, 'r') as f:
            data_list = f.readlines()

        # 数据集中的样本数量
        self.n_data = len(data_list)

        self.img_paths = []
        self.img_labels = []

        for data_item in data_list:
            # 读取文件名
            self.img_paths.append(data_item[:-3])
            # 读取图片标签
            self.img_labels.append(data_item[-2])

    def __getitem__(self, item):
        """
        获取数据集中指定索引位置的样本。

        参数:
            item (int): 样本的索引位置。

        返回:
            tuple: 包含图片和标签的元组。

        """
        img_path, label = self.img_paths[item], self.img_labels[item]
        img = Image.open(os.path.join(self.root, img_path)).convert('RGB')

        if self.transform is not None:
            img = self.transform(img)
            label = int(label)

        return img, label

    def __len__(self):
        """
        获取数据集的样本数量。

        返回:
            int: 数据集的样本数量。

        """
        return self.n_data
