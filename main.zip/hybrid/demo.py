"""
该代码文件实现了一个预测展示函数 predict，用于创建模型并根据指定大小选取目标域的样本进行预测。
函数首先加载指定的模型权重参数 state_dict，然后从目标域数据集中随机选择一定数量的样本进行预测。
预测结果以可视化方式展示，包括预测值、真实值和样本图像。
该文件同样定义了入口代码，用于调用 predict 函数进行项目展示。
"""
import datetime
import glob
import os
import random
import sys
import time

import numpy as np
import torch.backends.cudnn as cudnn
import torch.utils.data
from matplotlib import pyplot as plt

from dataset_transform import img_transform_target, dataset_target_test_without_transform
from model import CNNModel

model_root = 'models'


def predict(state_dict, size_limit=-1):
    """
    预测展示函数，根据指定的参数创建模型，并根据指定的大小选取来自目标域的样本，
    对这些样本进行预测，并将预测值、真实值、样本数据以可视化的方式展示出来。

    参数:
        - state_dict (dict): 模型的状态字典，包含模型的权重参数。
        - size_limit (int): 选取样本的数量限制。默认值为-1，表示不限制样本的数量。

    返回:
        None

    """
    cuda = True
    cudnn.benchmark = True

    dataset = dataset_target_test_without_transform

    if size_limit < 0 or len(dataset) <= size_limit:
        size_limit = len(dataset)
    indices = np.random.choice(len(dataset), size_limit, replace=False)

    n_cols = 5
    n_rows = (size_limit + n_cols - 1) // n_cols

    my_net = CNNModel()
    my_net.load_state_dict(state_dict)
    my_net = my_net.eval()
    if cuda:
        my_net = my_net.cuda()

    raw_images = [dataset[i][0] for i in indices]
    true_labels = np.array([dataset[i][1] for i in indices])
    normalized_images = torch.stack([img_transform_target(x) for x in raw_images])

    if cuda:
        normalized_images = normalized_images.cuda()

    class_output, _ = my_net(input_data=normalized_images, alpha=0)
    predicted_labels = class_output.data.max(1, keepdims=False).indices.cpu().numpy()

    for j in range(size_limit):
        plt.subplot(n_rows, n_cols, j + 1)
        fig = plt.imshow(raw_images[j], interpolation='none')
        fig.axes.get_xaxis().set_visible(False)
        fig.axes.get_yaxis().set_visible(False)
        plt.title("Predicted: {}\nTrue: {}".format(predicted_labels[j], true_labels[j]), {
            'color': 'green' if predicted_labels[j] == true_labels[j] else 'red'
        })

    plt.savefig(datetime.datetime.now().strftime("demo_%Y%m%d_%H%M%S.png"), dpi=300)
    plt.show()


# 调用 predict 进行项目展示的入口
if __name__ == "__main__":
    # 指定随机数种子并输出，
    # 在需要时，可以使用相同的随机数种子来完美复现。
    manual_seed = random.randint(1, 10000)
    random.seed(manual_seed)
    torch.manual_seed(manual_seed)
    np.random.seed(manual_seed)
    print("Using random seed: {}".format(manual_seed))
    plt.suptitle("Using random seed: {}".format(manual_seed))

    # 搜索获取所有参数文件
    pt_files = glob.glob('**/*.pt', root_dir=model_root, recursive=True)

    if len(pt_files) == 0:
        print("No .pt files found in the model_root directory.")
        sys.exit(-10001)

    print("Found the following files of model parameters:")
    for i, file in enumerate(pt_files):
        print("{}. {}".format(i + 1, file))

    # 询问用户选择
    choice = int(input("Choose a file (enter the corresponding number): "))

    if 1 <= choice <= len(pt_files):
        # 选中的文件路径
        print("File chosen: " + pt_files[choice - 1])
        selected_file = os.path.join(model_root, pt_files[choice - 1])
    else:
        print("Invalid choice.")
        sys.exit(-10001)

    # 输出运行时间
    time_start = time.monotonic()
    predict(torch.load(selected_file), 12)
    time_elapsed = time.monotonic() - time_start
    print('Time elapsed: {}s\n'.format(time_elapsed))
