"""
本文件定义了该项目用的模型的整体结构
模型中的部分子结构将在 class_qmodel.py 和 domain_qmodel.py 中定义
"""

import torch.nn as nn

from class_qmodel import ClassQuantumNet
from domain_qmodel import DomainQuantumNet
from functions import ReverseLayerF


class CNNModel(nn.Module):
    """
    模型整体
    """

    def __init__(self, domain_adaptation_enabled=None):
        super().__init__()
        self.domain_adaptation_enabled = domain_adaptation_enabled

        # 定义特征提取网络的结构
        # 详见项目报告书中的网络结构图
        self.feature = nn.Sequential()
        self.feature.add_module('f_conv1', nn.Conv2d(3, 64, kernel_size=5))  # batch_size*64*24*24
        self.feature.add_module('f_bn1', nn.BatchNorm2d(64))
        self.feature.add_module('f_pool1', nn.MaxPool2d(2))  # batch_size*64*12*12
        self.feature.add_module('f_relu1', nn.ReLU(True))
        self.feature.add_module('f_conv2', nn.Conv2d(64, 50, kernel_size=5))  # batch_size*50*8*8
        self.feature.add_module('f_bn2', nn.BatchNorm2d(50))
        self.feature.add_module('f_drop1', nn.Dropout2d())
        self.feature.add_module('f_pool2', nn.MaxPool2d(2))  # batch_size*50*4*4
        self.feature.add_module('f_relu2', nn.ReLU(True))

        self.classquantumnet = ClassQuantumNet()

        self.domainquantumnet = DomainQuantumNet()

    def forward(self, input_data, alpha=0.01):
        # 格式化输入数据，将其转换为 3 通道 28*28 的图片
        input_data = input_data.expand(input_data.data.shape[0], 3, 28, 28)

        feature = self.feature(input_data)

        # 将特征图转换为一维向量
        feature = feature.view(-1, 50 * 4 * 4)

        # 获取标签分类器的输出
        class_output = self.classquantumnet(feature)

        # 判断是否需要域分类器的输出，域分类器将在以下情况下启用：
        # 1. domain_adaptation_enabled == None（未指定），
        #    则在训练模式（training mode）下自动启用，在求解模式（evaluation mode）下自动关闭
        # 2. domain_adaptation_enabled != None（已指定），
        #    则根据指定的参数值来启用或关闭
        if self.training if self.domain_adaptation_enabled is None else self.domain_adaptation_enabled:
            # 需要域分类器的输出

            # 应用梯度反转算子（ReverseLayerF）
            # 对前向传播无影响
            # 但在反向传播（backward）时将反转梯度并乘以权重因子 alpha
            reverse_feature = ReverseLayerF.apply(feature, alpha)

            # 获取域分类器的输出
            domain_output = self.domainquantumnet(reverse_feature)

            # 同时返回标签分类器和域分类器的输出
            return class_output, domain_output
        else:
            # 域分类器的输出已关闭，我们只需要返回标签分类器的输出
            return class_output, None