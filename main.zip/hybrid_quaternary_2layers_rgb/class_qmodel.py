"""
本文件定义了标签分类器的结构
标签分类器由预处理、量子网络、后处理组成
"""

import numpy as np
import torch
from torch import nn

from quantum_net import QuantumFCLayer

n_qubits = 4  # 量子比特数量


class ClassQuantumNet(nn.Module):
    """
    标签分类器
    """

    def __init__(self):
        super().__init__()
        self.pre_net = nn.Linear(50 * 4 * 4, n_qubits)
        self.quantum_net = QuantumFCLayer()
        self.Softmax = nn.LogSoftmax(dim=1)

    def forward(self, input_features):
        """
        前向传播流程如下：
        输入特征 input_features 被传入预处理网络层 pre_net，该层将输入特征转换为量子网络的输入维度。
        经过预处理网络层后，得到预处理的输出 pre_out。
        预处理的输出经过 torch.tanh 函数进行正则化，将输出范围限制在 [-1, 1]。
        正则化后的结果乘以 np.pi，将其值正则化到 [-pi, pi] 的范围内，作为量子网络的角度输入 q_in。
        q_in 作为输入传入量子网络层 quantum_net，执行量子计算操作，得到量子网络的输出 q_out。
        q_out 经过 LogSoftmax 层进行分类概率的计算，得到最终的对数概率向量。
        """
        pre_out = self.pre_net(input_features)
        q_in = torch.tanh(pre_out) * np.pi
        q_out = self.quantum_net(q_in)

        return self.Softmax(q_out)
